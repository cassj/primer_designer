# ABSTRACT: Class for annotations regarding position in a tile 
use strict;
use warnings;
package Buckley::Annotation::Result::TilePosition;
{
  $Buckley::Annotation::Result::TilePosition::VERSION = '0.001';
}
use base 'Bio::Annotation::SimpleValue';


1;

__END__
=pod

=head1 NAME

Buckley::Annotation::Result::TilePosition - Class for annotations regarding position in a tile 

=head1 VERSION

version 0.001

=head1 SYNOPSIS

  use Bio::Annotation::Collection;
  use Buckley::Annotation::Result::TilePosition;

  my $col   = Bio::Annotation::Collection->new();
  my $tilepos = Buckley::Annotation::Result::TilePosition->new(-position => $pos_in_tile);
  $col->add_Annotation($tilename, $tilepos);

=head1 DESCRIPTION

Just a subclass of Bio::Annotation::SimpleValue.

=head1 NAME

Buckley::Annotation::Result::TilePosition - Annotation class for a tiling of primers or probes

=head1 AUTHOR 

Cass Johnston <cassjohnston@gmail.com>

=head1 AUTHOR

Cass Johnston <cassjohnston@gmail.com>

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by Cass Johnston.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut

