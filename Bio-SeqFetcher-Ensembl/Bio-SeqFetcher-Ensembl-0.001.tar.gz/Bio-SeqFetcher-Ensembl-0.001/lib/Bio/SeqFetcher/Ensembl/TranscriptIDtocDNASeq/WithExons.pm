# ABSTRACT: Fetch cDNA sequence as Bio::Seq from TranscriptID
package Bio::SeqFetcher::Ensembl::TranscriptIDtocDNASeq::WithExons;
BEGIN {
  $Bio::SeqFetcher::Ensembl::TranscriptIDtocDNASeq::WithExons::VERSION = '0.001';
}
BEGIN {
  $Bio::SeqFetcher::Ensembl::TranscriptIDtocDNASeq::WithExons::VERSION = '0.001';
}
use base 'Bio::SeqFetcher::Ensembl::TranscriptIDtocDNASeq';

use Bio::SeqFeature::Generic;

sub description{
  return "Returns cDNA sequence, with exon boundaries marked as Bio::SeqFeature::ExonBoundary SeqFeatures, given an Ensembl Transcript ID";
}



sub _make_seqs{
  my ($self,@transcripts) = @_;
  my @seqs;
  foreach my $trsc (@transcripts){

    # A transcript is just a collection of exons and possibly a translation
    # defining the coding and non coding regions.

    # Get exons (in order they appear in transcript, although start and end are top strand)
    my $trsc_exons = $trsc->get_all_Exons;
    my $seq;

    my $id = $trsc->stable_id;
    foreach my $exon (@$trsc_exons){
      my $strand = $exon->strand;
      my $chr = $exon->slice->seq_region_name;
      my $start = $exon->start;
      my $end = $exon->end;
      my $exon_id = $exon->stable_id;

      #fetch the transcript sequence
      my $slice = $self->_slice_adap->fetch_by_region('chromosome', $chr, $start, $end, $strand);
      $seq = $seq.$slice->seq;
    }

    #concatenation of exon sequences to Bio::Seq:
    $seq = Bio::Seq->new(-seq => $seq,
			 -id  => $id);

    #Now we need to add the exon boundaries as features:
    my @exon_lengths = map {$_->length} @$trsc_exons;
    pop @exon_lengths;  # except the last one

    my $pos = 0;
    foreach (@exon_lengths){
      $pos = $pos+$_;
      @Bio::SeqFeature::ExonBoundary::ISA = 'Bio::SeqFeature::Generic';
      my $feat = Bio::SeqFeature::ExonBoundary->new(
						    '-start'  => $pos,
						    '-end'    => $pos,
						    '-strand' => 1, # everything should be in transcript direction now.
						    '-display_name' => 'exon boundary'
					      );
      $seq->add_SeqFeature($feat);
    }
    push @seqs, $seq;
  }
  return @seqs;
}

1;



__END__
=pod

=head1 NAME

Bio::SeqFetcher::Ensembl::TranscriptIDtocDNASeq::WithExons - Fetch cDNA sequence as Bio::Seq from TranscriptID

=head1 VERSION

version 0.001

=head2 description

=head2 _make_seqs

  Internal use.
  Generates sequence objects from Bio::Ensembl::Genes. 

=head1 AUTHOR

Cass Johnston <cassjohnston@gmail.com>

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by Cass Johnston.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut

