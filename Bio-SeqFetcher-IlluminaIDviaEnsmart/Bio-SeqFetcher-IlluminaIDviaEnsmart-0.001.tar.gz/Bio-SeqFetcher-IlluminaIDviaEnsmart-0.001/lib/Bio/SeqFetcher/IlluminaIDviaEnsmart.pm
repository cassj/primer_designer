# ABSTRACT: what this module is for
use strict;
use warnings;
package Bio::SeqFetcher::IlluminaIDviaEnsmart;
BEGIN {
  $Bio::SeqFetcher::IlluminaIDviaEnsmart::VERSION = '0.001';
}
BEGIN {
  $Bio::SeqFetcher::IlluminaIDviaEnsmart::VERSION = '0.001';
}

sub method_name{
  my ($self) = @_;
  return;
}



1;
__END__
=pod

=head1 NAME

Bio::SeqFetcher::IlluminaIDviaEnsmart - what this module is for

=head1 VERSION

version 0.001

=head1 SYNOPSIS

# Synopsis code demonstrating the module goes here

=head1 DESCRIPTION

A description about this module.

=head2 method_name

Title    : method_name
Usage    : Some small examples of method usage
Function : Some description about what the method does
Returns  : What the method does
Args     : What arguments the method takes

=head1 NAME

Bio::SeqFetcher::IlluminaIDviaEnsmart - quick description

=head1 VERSION

version 0.001

=head1 FEEDBACK

=head2 Mailing Lists

User feedback is an integral part of the evolution of this and other
Bioperl modules. Send your comments and suggestions preferably to the
Bioperl mailing list. Your participation is much appreciated. 

  bioperl-l@bioperl.org                  - General discussion
  http://bioperl.org/wiki/Mailing_lists  - About the mailing lists

=head2 Reporting Bugs 

Report bugs to the Bioperl bug tracking system to help us keep track
of the bugs and their resolution. Bug reports can be submitted via the
web:

  http://bugzilla.open-bio.org/  

=head1 AUTHOR - Cass Johnston <cassjohnston@gmail.com>

The author(s) and contact details should be included here (this insures you get credit for creating the module.  
Lesser contributions can be documented in a separate CONTRIBUTORS section if you prefer. 

=head1 AUTHOR

Cass Johnston <cassjohnston@gmail.com>

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by Cass Johnston.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut

